
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/game.ts
import { getStore } from "@netlify/blobs";

// lib/call.ts
var CallError = class extends Error {
  constructor(message, status = 400) {
    super(message);
    this.status = status;
  }
  status;
};
var uuid = (v) => typeof v === "string" && /^[a-f0-9-]{36}$/i.test(v);
async function callAction(store, code, token, action, b, now) {
  const roomRecord = await store.getWithMetadata(code, { type: "json", consistency: "strong" });
  if (!roomRecord) throw new CallError("Room not found.", 404);
  const room = roomRecord.data, p = room.players.find((p2) => p2.token === token);
  if (!p) throw new CallError("Your session is invalid.", 401);
  if (now - room.touched > 864e5) throw new CallError("Room expired.", 410);
  const key = "call-" + code;
  for (let attempt = 0; attempt < 20; attempt++) {
    const record = await store.getWithMetadata(key, { type: "json", consistency: "strong" });
    if (record && !record.etag) throw new CallError("Storage version missing.", 503);
    const call = record ? record.data : { members: [], signals: [], revision: 0 };
    const before = JSON.stringify(call);
    call.members = call.members.filter((m) => now - m.seen < 25e3);
    call.signals = call.signals.filter((s) => s.expires > now && call.members.some((m) => m.id === s.from && m.session === s.fromSession) && call.members.some((m) => m.id === s.to && m.session === s.toSession));
    let me = call.members.find((m) => m.id === p.id);
    if (action === "call-join") {
      if (!uuid(b.callSession) || typeof b.mic !== "boolean" || typeof b.camera !== "boolean") throw new CallError("Invalid call settings.");
      if (me && me.session !== b.callSession) call.signals = call.signals.filter((s) => s.from !== p.id && s.to !== p.id);
      call.members = call.members.filter((m) => m.id !== p.id);
      me = { id: p.id, session: b.callSession, mic: b.mic, camera: b.camera, seen: now };
      call.members.push(me);
    } else if (action === "call-leave") {
      if (me?.session === b.callSession) {
        call.members = call.members.filter((m) => m.id !== p.id);
        call.signals = call.signals.filter((s) => s.from !== p.id && s.to !== p.id);
        me = void 0;
      }
    } else if (action === "call-state") {
      if (b.callSession) {
        if (!me || me.session !== b.callSession) throw new CallError("Call session expired or opened in another tab. Rejoin the call.", 409);
        if (now - me.seen >= 5e3) me.seen = now;
        if (Array.isArray(b.ack) && b.ack.length <= 64) call.signals = call.signals.filter((s) => !(s.to === p.id && s.toSession === me.session && b.ack.includes(s.id)));
      }
    } else {
      if (!me || me.session !== b.callSession) throw new CallError("Join the call first.", 409);
      if (action === "call-status") {
        if (typeof b.mic !== "boolean" || typeof b.camera !== "boolean") throw new CallError("Invalid call settings.");
        me.mic = b.mic;
        me.camera = b.camera;
        me.seen = now;
      } else if (action === "call-signal") {
        const to = call.members.find((m) => m.id === b.to && m.session === b.toSession);
        const d = b.description;
        if (!to || to.id === p.id) throw new CallError("Other player has left the call.", 409);
        if (!uuid(b.requestId) || !d || !["offer", "answer"].includes(d.type) || typeof d.sdp !== "string" || d.sdp.length > 24e3 || !d.sdp.startsWith("v=0")) throw new CallError("Invalid call signal.");
        if (!call.signals.some((s) => s.id === b.requestId)) {
          call.signals = call.signals.filter((s) => !(s.from === p.id && s.to === to.id && s.description.type === d.type));
          call.signals.push({ id: b.requestId, from: p.id, fromSession: me.session, to: to.id, toSession: to.session, description: { type: d.type, sdp: d.sdp }, expires: now + 6e4 });
        }
        me.seen = now;
      } else throw new CallError("Unknown call action.", 404);
    }
    if (JSON.stringify(call) !== before) {
      call.revision++;
      const write = await store.setJSON(key, call, record ? { onlyIfMatch: record.etag } : { onlyIfNew: true });
      if (!write.modified) {
        await new Promise((resolve) => setTimeout(resolve, Math.min(60, attempt * 5)));
        continue;
      }
    }
    return { revision: call.revision, members: call.members.map((m) => ({ ...m, name: room.players.find((p2) => p2.id === m.id)?.name || "Player" })), signals: me?.session === b.callSession ? call.signals.filter((s) => s.to === p.id && s.toSession === me.session) : [] };
  }
  throw new CallError("Call is busy. Please retry.", 503);
}

// lib/service.ts
import { randomBytes as randomBytes2, randomUUID as randomUUID2 } from "node:crypto";

// lib/game.ts
import { randomBytes, randomUUID } from "node:crypto";
var PRIZES = [4, 5, 6, 7, 8, 10];
function player(name, now) {
  const clean = String(name || "").trim().slice(0, 20);
  if (!clean) throw Error("Enter a player name.");
  return { id: randomUUID(), token: randomBytes(24).toString("hex"), name: clean, credits: 24, score: 0, bid: null, seen: now };
}
function begin(r, now) {
  r.round = 0;
  r.carry = 0;
  r.history = [];
  r.phase = "bidding";
  r.gameId = randomUUID();
  r.players.forEach((p) => {
    p.credits = 24;
    p.score = 0;
    p.bid = null;
  });
  r.deadline = now + 3e4;
}
function next(r, now) {
  r.round++;
  r.phase = "bidding";
  r.deadline = now + 3e4;
  r.players.forEach((p) => p.bid = null);
}
function bid(r, p, value) {
  if (r.phase !== "bidding") throw Error("Bidding is closed.");
  if (p.bid !== null) throw Error("Your bid is already locked.");
  if (typeof value !== "number" || !Number.isInteger(value) || value < 0 || value > Math.min(8, p.credits)) throw Error("Invalid bid.");
  p.bid = value;
}
function settle(r, now) {
  if (r.phase !== "bidding" || now < r.deadline && !r.players.every((p) => p.bid !== null)) return false;
  const bids = r.players.map((p) => ({ id: p.id, name: p.name, bid: p.bid ?? 0 }));
  const highest = Math.max(...bids.map((p) => p.bid)), leaders = bids.filter((p) => p.bid === highest);
  const winner = highest > 0 && leaders.length === 1 ? leaders[0] : null, points = r.prizes[r.round] + r.carry;
  for (const p of r.players) {
    p.credits -= p.bid ?? 0;
    if (p.id === winner?.id) p.score += points;
  }
  r.history.push({ round: r.round + 1, points, bids, winner: winner?.id ?? null });
  r.carry = winner ? 0 : points;
  r.phase = r.round === r.prizes.length - 1 ? "finished" : "reveal";
  r.deadline = null;
  return true;
}
function winners(r) {
  const sorted = [...r.players].sort((a, b) => b.score - a.score || b.credits - a.credits);
  return sorted.filter((p) => p.score === sorted[0].score && p.credits === sorted[0].credits).map((p) => p.id);
}
function snapshot(r, id, now) {
  return { code: r.code, host: r.host, phase: r.phase, round: r.round, carry: r.carry, deadline: r.deadline, serverTime: now, history: r.history, chat: r.chat, gameId: r.gameId, revision: r.revision, prizes: r.prizes, winners: r.phase === "finished" ? winners(r) : [], players: r.players.map((p) => ({ id: p.id, name: p.name, credits: p.credits, score: p.score, locked: p.bid !== null, bid: p.id === id ? p.bid : void 0, online: now - p.seen < 2e4 })) };
}

// lib/service.ts
var Problem = class extends Error {
  constructor(message, status = 400) {
    super(message);
    this.status = status;
  }
  status;
};
var json = (data, status = 200) => Response.json(data, { status, headers: { "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" } });
function createHandler(getStore2, { clock = Date.now, prizes = PRIZES } = {}) {
  return async (req) => {
    try {
      if (req.method !== "POST") return json({ error: "Use POST." }, 405);
      const origin = req.headers.get("origin");
      if (origin && origin !== new URL(req.url).origin) return json({ error: "Origin rejected." }, 403);
      const raw = await req.text();
      if (raw.length > 32768) throw new Problem("Request too large.", 413);
      let body;
      try {
        body = JSON.parse(raw);
      } catch {
        throw new Problem("Invalid JSON.");
      }
      if (!body || Array.isArray(body) || typeof body !== "object") throw new Problem("Invalid request.");
      const action = String(body.action || "");
      if (!["create", "join", "state", "start", "bid", "next", "chat", "call-join", "call-leave", "call-state", "call-status", "call-signal"].includes(action)) throw new Problem("Unknown action.", 404);
      const store = getStore2(), now = clock();
      if (action === "create") {
        if (!String(body.name || "").trim()) throw new Problem("Enter a player name.");
        const p = player(body.name, now);
        for (let attempt = 0; attempt < 8; attempt++) {
          const code2 = randomBytes2(3).toString("hex").toUpperCase();
          const r = { code: code2, host: p.id, phase: "lobby", round: 0, carry: 0, history: [], chat: [], players: [p], deadline: null, touched: now, prizes: [...prizes], gameId: randomUUID2(), revision: 0, requests: [] };
          if ((await store.setJSON(code2, r, { onlyIfNew: true })).modified) return json({ room: code2, id: p.id, token: p.token });
        }
        throw new Problem("Could not reserve a room. Please retry.", 503);
      }
      const code = String(body.room || body.code || "").trim().toUpperCase();
      if (!/^[A-F0-9]{6}$/.test(code)) throw new Problem("Room code not found.", 404);
      const token = req.headers.get("authorization")?.replace(/^Bearer /, "");
      if (action === "join" && !String(body.name || "").trim()) throw new Problem("Enter a player name.");
      if (action.startsWith("call-")) return json(await callAction(store, code, token, action, body, now));
      const joined = action === "join" ? player(body.name, now) : null;
      const requestId = String(body.requestId || "");
      if (action !== "state" && !/^[a-zA-Z0-9-]{8,80}$/.test(requestId)) throw new Problem("A request ID is required.");
      for (let attempt = 0; attempt < 20; attempt++) {
        const record = await store.getWithMetadata(code, { type: "json", consistency: "strong" });
        if (!record) throw new Problem("Room not found. Create or join a new room.", 404);
        if (!record.etag) throw new Problem("Storage version missing. Please retry.", 503);
        const r = record.data;
        if (now - r.touched > 864e5) throw new Problem("Room expired. Create a new room.", 410);
        let p = joined || r.players.find((p2) => p2.token === token);
        if (!p) throw new Problem("Your session is invalid. Rejoin the room.", 401);
        const dedupeKey = (joined ? "join" : p.id) + ":" + requestId;
        if (r.requests.includes(dedupeKey)) {
          if (joined) {
            const recovered = r.players.find((p2) => p2.token === r.requests[r.requests.indexOf(dedupeKey) + 1]);
            if (recovered) return json({ room: code, id: recovered.id, token: recovered.token });
          } else return json(snapshot(r, p.id, now));
        }
        let changed = settle(r, now), failure;
        try {
          if (action === "join") {
            if (r.phase !== "lobby") throw new Problem("This game has already started.");
            if (r.players.length >= 8) throw new Problem("Room is full (8 players).");
            if (r.players.some((x) => x.name.toLowerCase() === p.name.toLowerCase())) throw new Problem("Choose a different name.");
            r.players.push(p);
            changed = true;
          } else if (action === "state") {
            if (now - p.seen >= 5e3) {
              p.seen = now;
              changed = true;
            }
          } else {
            if (body.gameId !== r.gameId) throw new Problem("Game changed. Refresh and try again.", 409);
            if (action === "start") {
              if (p.id !== r.host) throw new Problem("Only the host can start.", 403);
              if (!["lobby", "finished"].includes(r.phase)) throw new Problem("Game already in progress.");
              if (r.players.length < 2) throw new Problem("At least 2 players are needed.");
              begin(r, now);
            } else if (action === "bid") {
              if (body.round !== r.round) throw new Problem("Round changed. Try again.", 409);
              bid(r, p, body.bid);
              settle(r, now);
            } else if (action === "next") {
              if (p.id !== r.host || r.phase !== "reveal") throw new Problem("Waiting for the host to continue.");
              if (body.round !== r.round) throw new Problem("Round changed. Try again.", 409);
              next(r, now);
            } else if (action === "chat") {
              const text = String(body.text || "").trim().slice(0, 240);
              if (!text) throw new Problem("Enter a message.");
              if (now - (p.lastChat || 0) < 700) throw new Problem("Please wait a moment.", 429);
              p.lastChat = now;
              r.chat.push({ name: p.name, text });
              r.chat = r.chat.slice(-40);
            }
            p.seen = now;
            changed = true;
          }
        } catch (e) {
          failure = e instanceof Problem ? e : new Problem(e.message);
        }
        if (changed) {
          r.touched = now;
          r.revision++;
          if (!failure && action !== "state") {
            r.requests.push(dedupeKey);
            if (joined) r.requests.push(p.token);
            r.requests = r.requests.slice(-160);
          }
          const result = await store.setJSON(code, r, { onlyIfMatch: record.etag });
          if (!result.modified) {
            await new Promise((resolve) => setTimeout(resolve, Math.min(60, attempt * 5)));
            continue;
          }
        }
        if (failure) throw failure;
        return joined ? json({ room: code, id: p.id, token: p.token }) : json(snapshot(r, p.id, now));
      }
      throw new Problem("Room is busy. Please try again.", 409);
    } catch (e) {
      if (e instanceof Problem || e instanceof CallError) return json({ error: e.message }, e.status);
      console.error("Game request failed", e);
      return json({ error: "Game service is temporarily unavailable. Please retry." }, 503);
    }
  };
}

// netlify/functions/game.ts
var game_default = createHandler(() => getStore({ name: "vault-wars-rooms-v1", consistency: "strong" }));
export {
  game_default as default
};
